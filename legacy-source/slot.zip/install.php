<?
include "zbpath.php";
include $_zb_path."_head.php";
?>

<html>

<head>
<title>�ε𽽷� ��ġ</title>
<script>
<!--
function Move(value)
{
	if(value == "uninstall")
	{
		if(confirm("��ġ�� �÷��� ��� ���ŵ˴ϴ�. ����Ͻðڽ��ϱ�?") == false)
	  		return false;
	}
	menu.act.value = value;
	menu.submit();
}
//-->
</script>
</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red">
<form name="menu" method="post" action=<?=$PHP_SELF?>>
<input type="hidden" name="act">
<table style="border-collapse:collapse;" align="center" cellspacing="0" width="302">
    <tr>
        <td width="298" height="30" bgcolor="#FFF3F3" style="border-top-width:2; border-right-width:1; border-bottom-width:1; border-left-width:1; border-top-color:rgb(249,157,157); border-right-color:rgb(153,153,153); border-bottom-color:rgb(153,153,153); border-left-color:rgb(153,153,153); border-style:solid;">
            
            <p align="center"><span style="font-size:9pt;"><font color="#666666">�ε𽽷� 
            ������ ��� </font></span></p>
            
        </td>
    </tr>
    
<? 
if(!$act) 
{
?>
    <tr>
        <td width="298" height="100" style="border-top-width:1; border-right-width:1; border-bottom-width:2; border-left-width:1; border-top-color:rgb(153,153,153); border-right-color:rgb(153,153,153); border-bottom-color:rgb(249,157,157); border-left-color:rgb(153,153,153); border-style:solid;">
            <p align="center"><span style="font-size:9pt;cursor:hand;" onclick=Move('install');><font color="#666666">[ 
            ��ġ�ϱ� ]</font></span></p>
            <p align="center"><span style="font-size:9pt;cursor:hand;" onclick=Move('uninstall');><font color="#666666">[ 
            �����ϱ� ]</font></span></p>
        </td>
    </tr>
<?
}

elseif($act == "install")
{
	$table = array("install");

	echo "<tr><td width='100%' style='border-top-width:1; border-right-width:1; border-bottom-width:2; border-left-width:1; border-top-color:rgb(153,153,153); border-right-color:rgb(153,153,153); border-bottom-color:rgb(249,157,157); border-left-color:rgb(153,153,153); border-style:solid;' align='center'>";
	
	for($i=0; $i<count($table); $i++)
		if(!file_exists($table[$i].".sql"))
		{
		 	echo "install.sql ������ �������� �ʽ��ϴ�.";
			exit;
		}

	echo "<p> ������̺��� �����մϴ�.</p>";

	
	for($j=0; $j<count($table); $j++)
	{
		$data = file($table[$j].".sql");
		
		echo "�÷� ���� ���Դϴ�.";
	

		$i = 0;
		
		while($i < count($data))
			mysql_query($data[$i++]) or error(mysql_error());
		
	}
		
	echo "<p>���������� ��ġ�Ͽ����ϴ�.</p>";
	echo "<br/>";
	echo "</td></tr>";
}
elseif($act == "uninstall")
{
	$table = array("uninstall");
	
	echo "<tr><td width='100%' style='border-top-width:1; border-right-width:1; border-bottom-width:2; border-left-width:1; border-top-color:rgb(153,153,153); border-right-color:rgb(153,153,153); border-bottom-color:rgb(249,157,157); border-left-color:rgb(153,153,153); border-style:solid;' align='center'>";

	for($i=0; $i<count($table); $i++)
		if(!file_exists($table[$i].".sql"))
		{
		 	echo "uninstall.sql ������ �������� �ʽ��ϴ�.";
			exit;
		}

	echo "<p> ������̺��� �����մϴ�.</p>";

	
	for($j=0; $j<count($table); $j++)
	{
		$data = file($table[$j].".sql");
		
		echo "�÷� ���� ���Դϴ�.";
	

		$i = 0;
		
		while($i < count($data))
			mysql_query($data[$i++]) or error(mysql_error());
		
	}
	echo "<p>���������� �����Ͽ����ϴ�.</p>";
	echo "<br/>";
	echo "</td></tr>";
}
?>
</table>
</form>
</body>

</html>
