<?
include "zbpath.php";
include $_zb_path."_head.php";

$reg_date=time();	 // ������ �ð�����
$mode=0;			 // ���� ���
$slotclr="#ffffff";	 // ����
$rankdb=0;			 // ��ŷ ������Ʈ ����
//$betmoney=100;	 // ���øӴ�
$title="��Ÿ�û�";	 // �û��

// ���� ������ ���̺���
$all7=0;
$allh=0;
$alll=0;
$cro7=0;

// ���� ȸ�� ����
$sdata = mysql_fetch_array(mysql_query("select * from zetyx_member_table where user_id='$member[user_id]'",$connect));

if($member[no]&&$sdata[bar]>0) // ��� ���� �� ���񽺰� ������ ���
{
	include "bar.php";
	$mode=1;
	$slotclr="#CCF6FD";
	echo "<script>top.setBetFalse();</script>";
}
else if($member[no]&&$sdata[bellbonus]>0) // ��� ���� �� ���񽺰� ������ ���
{
	include "bell.php";
	$mode=2;
	$slotclr="#CCF6FD";
	echo "<script>top.setBetFalse();</script>";
}
else
{
	include "normal.php";
	$mode=0;
	$slotclr="#ffffff";
	echo "<script>top.setBetTrue();</script>";
}

if($doublepoint==5)		$slotclr="#FFBBBB";		// ���� 5��� ����
else if($doublepoint==3)	$slotclr="#BBBBFF";	// ���� 3��� ����
else if($doublepoint==2)	$slotclr="#BBFFBB";	// ���� 2��� ����

$img[1]="images/spin".$num[1].".gif";
$img[2]="images/spin".$num[2].".gif";
$img[3]="images/spin".$num[3].".gif";
$img[4]="images/spin".$num[4].".gif";
$img[5]="images/spin".$num[5].".gif";
$img[6]="images/spin".$num[6].".gif";
$img[7]="images/spin".$num[7].".gif";
$img[8]="images/spin".$num[8].".gif";
$img[9]="images/spin".$num[9].".gif";

if($member[no]&&$sdata[gamepoint]>=$betmoney&&$betmoney>=20) {
@mysql_query("update zetyx_member_table set gamepoint=gamepoint-$betmoney where user_id='$member[user_id]'",$connect) or error(mysql_error());

if($holds>0)
{
	if($h1=="true")
	{
		$num[1]=$sdata[box1];	$img[1]="images/stop".$num[1].".gif";
		$num[4]=$sdata[box4];	$img[4]="images/stop".$num[4].".gif";
		$num[7]=$sdata[box7];	$img[7]="images/stop".$num[7].".gif";
	}
	if($h2=="true")
	{
		$num[2]=$sdata[box2];	$img[2]="images/stop".$num[2].".gif";
		$num[5]=$sdata[box5];	$img[5]="images/stop".$num[5].".gif";
		$num[8]=$sdata[box8];	$img[8]="images/stop".$num[8].".gif";
	}
	if($h3=="true")
	{
		$num[3]=$sdata[box3];	$img[3]="images/stop".$num[3].".gif";
		$num[6]=$sdata[box6];	$img[6]="images/stop".$num[6].".gif";
		$num[9]=$sdata[box9];	$img[9]="images/stop".$num[9].".gif";
	}
	$allmode=100;
}



// ���� �˻�
function lineCheck($item,$linenum)
{
	global $bars;
	global $bells;
	global $gamemsg;
	global $mode;
	global $betmoney;
	
	$temp_point=0;

	if($item==1)			// ü��
		$temp_point=$betmoney;
	else if($item==2)		// ������
		$temp_point=($betmoney*1.2);
	else if($item==3)		// ����
		$temp_point=($betmoney*1.5);
	else if($item==4)		// ����
	{
		$temp_point=($betmoney*2.5);
		if(mode!=1)$bars=$bars+3;
		echo "<script>top.setBetFalse;</script>";
	}
	else if($item==5)	    // ����
		$temp_point=($betmoney*20);

	else if($item==6)		// ������
	{
		$bells=$bells+1;
	}
	else if($item==7)		// ����
	{
		//	���� ���ʽ��� ��ü
	}

	else if($item==8)		// ����
	{
		$temp_point=($betmoney*5);
		if(mode!=1)$bars=$bars+4;
		echo "<script>top.setBetFalse;</script>";
	}
	else if($item==9)		// ������
	{
		$temp_point=($betmoney*12);
		if(mode!=1)$bars=$bars+5;
		echo "<script>top.setBetFalse;</script>";
	}
	else if($item==0)		// ����
		$temp_point=($betmoney*2.5);
	else if($item==11)		// ���
		$temp_point=($betmoney*1.2);
	else if($item==12)		// ����
		$temp_point=($betmoney*2);
	
	if($item!=10)
	{	
		$gamemsg="Wins";
		echo "<script>lamp[$linenum-1]=1;</script>";
	}
	
	return $temp_point;
}

?>

<html>
<head>
<title>�ε� ���� ��Ÿ v1.0</title>
<script language="JavaScript">
<!--
var lamp = new Array(8);
var slot = new Array(9);

var gamemsg="";
var idx=0;
var allfruit=0;
var sevens=0;

// ���� ����
if(top.getSound())
	top.document.getElementById('effect_spin').play();

for(idx=0;idx<8;idx++)
{
	lamp[idx] = 0;
}
for(idx=0;idx<9;idx++)
{
	slot[idx] = 0;
}

function change(string) {

image_string = string;

string_length = image_string.length;

	while (string_length != 0){

	  place_space= image_string.indexOf(" ");

	  image_change_name = image_string.substring(5,place_space);

	  place_end = image_string.indexOf(")");

	  image_change_src = image_string.substring(place_space + 5,place_end);

	  object_image = eval("top.document."+image_change_name);

	  object_image.src=image_change_src;

	  string_lenght = image_string.length;

	  image_string = image_string.substring(place_end+1,string_lenght);

	  string_length = image_string.length;
	  }
}

// ȭ�� ���� üũ
function slotOn(value){
	
	var i=parseInt(value);
	slot[i-1]=1;
}

function slotOnAll(){
	var i;
	for(i=0;i<9;i++)
	{
		if(slot[i]==1)
			top.document.getElementById("slot"+(i+1)).style.backgroundColor="#FFBBBB";
	}
}
function slotSetAll(){
	var i;
	for(i=0;i<9;i++)
	{
		top.document.getElementById("slot"+(i+1)).style.backgroundColor="<?=$slotclr?>";
	}
}

// ���� ����
function lampOn(value){

	var temp = parseInt(value);
	top.document.getElementById("lamp"+(temp+1)).style.backgroundColor="#FF0000";
	switch(temp)
	{
		case 0:
			slotOn(4);slotOn(5);slotOn(6);
			break;
		case 1:
			slotOn(1);slotOn(2);slotOn(3);
			break;
		case 2:
			slotOn(7);slotOn(8);slotOn(9);
			break;
		case 3:
			slotOn(1);slotOn(5);slotOn(9);
			break;
		case 4:
			slotOn(3);slotOn(5);slotOn(7);
			break;
		case 5:
			slotOn(1);slotOn(4);slotOn(7);
			break;
		case 6:
			slotOn(2);slotOn(5);slotOn(8);
			break;
		case 7:
			slotOn(3);slotOn(6);slotOn(9);
			break;

	}
}
function lampOff(){
	var i;
	for(i=1;i<9;i++)
	{
		top.document.getElementById("lamp"+i).style.backgroundColor="#FFDDDD";
	}
}

function showHold(){
	top.document.getElementById("holdtext1").style.visibility="visible";
	top.document.getElementById("holdtext2").style.visibility="visible";
	top.document.getElementById("holdtext3").style.visibility="visible";
}

function hideHold(){
	top.document.getElementById("holdtext1").style.visibility="hidden";
	top.document.getElementById("holdtext2").style.visibility="hidden";
	top.document.getElementById("holdtext3").style.visibility="hidden";
}

function setting(value){

	var bonus='<?=$bars?>';
	var totalbonus=parseInt(value);
	var gap=1000;
	
	

	if(<?=$h1?>==false)
	{
		setTimeout("top.document.getElementById('i1').src='images/<?=$num[1]?>.gif'",gap);
		setTimeout("top.document.getElementById('i4').src='images/<?=$num[4]?>.gif'",gap+=200);
		setTimeout("top.document.getElementById('i7').src='images/<?=$num[7]?>.gif'",gap+=200);
		gap+=400;
	}

	if(<?=$h2?>==false)
	{
		setTimeout("top.document.getElementById('i2').src='images/<?=$num[2]?>.gif'",gap);
		setTimeout("top.document.getElementById('i5').src='images/<?=$num[5]?>.gif'",gap+=200);
		setTimeout("top.document.getElementById('i8').src='images/<?=$num[8]?>.gif'",gap+=200);
		gap+=400;
	}
	if(<?=$h3?>==false)
	{
		setTimeout("top.document.getElementById('i3').src='images/<?=$num[3]?>.gif'",gap);
		setTimeout("top.document.getElementById('i6').src='images/<?=$num[6]?>.gif'",gap+=200);
		setTimeout("top.document.getElementById('i9').src='images/<?=$num[9]?>.gif'",gap+=200);
		gap+=400;
	}	
	
	var i=0;

	for(i=0;i<8;i++)
	{
		if(lamp[i]==1)
			setTimeout("lampOn("+i+")",gap+400);

	}
	setTimeout("slotOnAll()",gap+400);
	
	setTimeout("top.document.getElementById('bar').value=gamemsg",gap+400);

	if(allfruit==9)
	{
		setTimeout("top.MM_showHideLayers('layer1','','hide','layer2','','show');",gap+=800);
		setTimeout("top.document.getElementById('snd').src='swf/fruits.html'",gap+=200);
		setTimeout("top.MM_showHideLayers('layer2','','hide','layer1','','show');",gap+=6000);
		setTimeout("top.setPlay()",gap);
		setTimeout("top.setHoldFalse()",gap);
	}
	else if(sevens>=5)
	{
		setTimeout("top.MM_showHideLayers('layer1','','hide','layer2','','show');",gap+=800);
		setTimeout("top.document.getElementById('snd').src='swf/seven.html'",gap+=200);
		setTimeout("top.MM_showHideLayers('layer2','','hide','layer1','','show');",gap+=10800);
		setTimeout("top.setPlay()",gap);
		setTimeout("top.setHoldFalse()",gap);
	}
	else if(gamemsg!="Game Over")
	{
		if((totalbonus < <?=$betmoney?>) && top.getSound())
			setTimeout("top.document.getElementById('effect_swin').play();",gap+=300);
		else if((totalbonus < <?=$betmoney*3?>) && top.getSound())
			setTimeout("top.document.getElementById('effect_mwin').play();",gap+=300);
		else if(totalbonus >=<?=$betmoney*100?>)
		{
			setTimeout("top.document.getElementById('effect_jp').movie='#';",gap+=300);
			setTimeout("top.document.getElementById('effect_jp').movie='swf/jackpot.swf';",gap);
			setTimeout("top.document.getElementById('effect_jp').loop=false;",gap+=5000);
		}
		else if(top.getSound())
				setTimeout("top.document.getElementById('effect_bwin').play();",gap+=500);
		
		setTimeout("top.setHoldFalse()",gap);
		setTimeout("top.setPlay()",gap+=500);
		
	}
	else
	{
		if(top.getSound())
			setTimeout("top.document.getElementById('effect_over').play();",gap+=300);
		
		setTimeout("top.setPlay()",gap+=500);

		if(<?=$holds?>>0 || <?=$mode?>!=0)
			setTimeout("top.setHoldFalse()",gap);
		else
		{
			setTimeout("top.setHoldTrue()",gap);
			setTimeout("showHold()",gap);
		}
	}
	
	if(top.getAuto()==true)
		setTimeout("top.replay()",gap+300);
	else
		setTimeout("top.focus()",gap+300);
}
//-->
</script>
<?
// ���� ��ũ��Ʈ ����! 

// Ȧ�� Ŭ����
echo "<script>top.holdClear();</script>";
echo "<script>hideHold();</script>";

// ���� ����
echo "<script>slotSetAll();</script>";

// ��������
echo "<script>lampOff();</script>";

// ���ư��� �̹��� �ʱ�ȭ
for($i=1;$i<10;$i++)
{
	echo "<script>top.document.getElementById('i".$i."').src='".$img[$i]."';</script>";
}

// ���ӸӴ� ǥ��
echo "<script>top.document.getElementById('moneytxt').value='".number_format($sdata[gamepoint])."';</script>";

// ���� ǥ��
echo "<script>top.document.getElementById('jackpottxt').value='$ ".number_format($jackpot)."';</script>";

// ������ ǥ��
echo "<script>top.document.getElementById('belltxt').value='".$sdata[bell]."';</script>";

// ���� ǥ��
if($mode==1) echo "<script>top.document.getElementById('servicetxt').value='".$sdata[bar]."';</script>";
else if($mode==2) echo "<script>top.document.getElementById('servicetxt').value='".$sdata[bellbonus]."';</script>";
else if($mode==0) echo "<script>top.document.getElementById('servicetxt').value='0';</script>";
		

// �޼��� �ʱ�ȭ
echo "<script>top.document.getElementById('bar').value='';</script>";

/* �û� ����Ʈ */
if($mode==2)
{
	for ($i=1;$i<10;$i++)
	{
		if($num[$i]==6||$num[$i]==7)
		{
			$bellcount=$bellcount+1;
			echo "<script>slotOn(".$i.");</script>";
		}
	}
	
	$total_points=$total_points+($bellcount*$betmoney);
	
}

/* ������ */
for ($i=1;$i<10;$i++)
{
	if($num[$i]==5)
	{
		$seven=$seven+1;
	}
}
if($seven>1)
{
	for ($i=1;$i<10;$i++)
	{
		if($num[$i]==5)
		{
			echo "<script>slotOn(".$i.");</script>";
		}
	}
}


/*����� ����*/
for ($i=1;$i<10;$i++)
{
	if($num[$i]==4||($num[$i]>7&&$num[$i]<10))
	$allbar=$allbar+1;
}

/*������ ����*/
for ($i=1;$i<10;$i++)
{
	if($num[$i]==6||$num[$i]==7)
	$allbell=$allbell+1;
}

if($allmode==100)	// �ñ׸��� �ƴϸ�
{
// ü�� �Ѱ�

 if($num[1]==1)	$total_points=$total_points+($betmoney*3/5);
 if($num[2]==1)	$total_points=$total_points+($betmoney/5);
 if($num[3]==1)	$total_points=$total_points+($betmoney/5);
 if($num[4]==1)	$total_points=$total_points+($betmoney/5);
 if($num[7]==1) $total_points=$total_points+($betmoney*2/5);

// ü�� �ΰ�

 if($num[4]==$num[5]&&$num[5]==1) $total_points=$total_points+($betmoney/5); //1����
 if($num[1]==$num[2]&&$num[2]==1) $total_points=$total_points+($betmoney/5); //2����
 if($num[7]==$num[8]&&$num[8]==1) $total_points=$total_points+($betmoney/5); //3����
 if($num[1]==$num[4]&&$num[4]==1) $total_points=$total_points+($betmoney/5); //4����
 if($num[2]==$num[5]&&$num[5]==1) $total_points=$total_points+($betmoney/5); //5����
 if($num[3]==$num[6]&&$num[6]==1) $total_points=$total_points+($betmoney/5); //6����
 if($num[1]==$num[5]&&$num[5]==1) $total_points=$total_points+($betmoney/5); //7����
 if($num[7]==$num[5]&&$num[5]==1) $total_points=$total_points+($betmoney/5); //8����

/* ���� */
  if($num[4]==$num[5]&&$num[5]==$num[6]) $total_points+=lineCheck($num[4],1); //1����
  if($num[1]==$num[2]&&$num[2]==$num[3]) $total_points+=lineCheck($num[1],2); //2����
  if($num[7]==$num[8]&&$num[8]==$num[9]) $total_points+=lineCheck($num[7],3); //3����
  if($num[1]==$num[5]&&$num[5]==$num[9]) $total_points+=lineCheck($num[1],4); //4����
  if($num[3]==$num[5]&&$num[5]==$num[7]) $total_points+=lineCheck($num[3],5); //5����
  if($num[1]==$num[4]&&$num[4]==$num[7]) $total_points+=lineCheck($num[1],6); //6����
  if($num[2]==$num[5]&&$num[5]==$num[8]) $total_points+=lineCheck($num[2],7); //7����
  if($num[3]==$num[6]&&$num[6]==$num[9]) $total_points+=lineCheck($num[3],8); //8����

/*��������*/
if(($num[4]==6||$num[4]==7)&&($num[5]==6||$num[5]==7)&&($num[6]==6||$num[6]==7)) $total_points+=lineCheck(12,1); //1����
if(($num[1]==6||$num[1]==7)&&($num[2]==6||$num[2]==7)&&($num[3]==6||$num[3]==7)) $total_points+=lineCheck(12,2); //2����
if(($num[7]==6||$num[7]==7)&&($num[8]==6||$num[8]==7)&&($num[9]==6||$num[9]==7)) $total_points+=lineCheck(12,3); //3����
if(($num[1]==6||$num[1]==7)&&($num[5]==6||$num[5]==7)&&($num[9]==6||$num[9]==7)) $total_points+=lineCheck(12,4); //4����
if(($num[3]==6||$num[3]==7)&&($num[5]==6||$num[5]==7)&&($num[7]==6||$num[7]==7)) $total_points+=lineCheck(12,5); //5����
if(($num[1]==6||$num[1]==7)&&($num[4]==6||$num[4]==7)&&($num[7]==6||$num[7]==7)) $total_points+=lineCheck(12,6); //6����
if(($num[2]==6||$num[2]==7)&&($num[5]==6||$num[5]==7)&&($num[8]==6||$num[8]==7)) $total_points+=lineCheck(12,7); //7����
if(($num[3]==6||$num[3]==7)&&($num[6]==6||$num[6]==7)&&($num[9]==6||$num[9]==7)) $total_points+=lineCheck(12,8); //8����


/*�������*/
if(($num[4]==4||$num[4]==8||$num[4]==9)&&($num[5]==4||$num[5]==8||$num[5]==9)&&($num[6]==4||$num[6]==8||$num[6]==9)) $total_points+=lineCheck(11,1);
if(($num[1]==4||$num[1]==8||$num[1]==9)&&($num[2]==4||$num[2]==8||$num[2]==9)&&($num[3]==4||$num[3]==8||$num[3]==9)) $total_points+=lineCheck(11,2);
if(($num[7]==4||$num[7]==8||$num[7]==9)&&($num[8]==4||$num[8]==8||$num[8]==9)&&($num[9]==4||$num[9]==8||$num[9]==9)) $total_points+=lineCheck(11,3);
if(($num[1]==4||$num[1]==8||$num[1]==9)&&($num[5]==4||$num[5]==8||$num[5]==9)&&($num[9]==4||$num[9]==8||$num[9]==9)) $total_points+=lineCheck(11,4);
if(($num[3]==4||$num[3]==8||$num[3]==9)&&($num[5]==4||$num[5]==8||$num[5]==9)&&($num[7]==4||$num[7]==8||$num[7]==9)) $total_points+=lineCheck(11,5);
if(($num[1]==4||$num[1]==8||$num[1]==9)&&($num[4]==4||$num[4]==8||$num[4]==9)&&($num[7]==4||$num[7]==8||$num[7]==9)) $total_points+=lineCheck(11,6);
if(($num[2]==4||$num[2]==8||$num[2]==9)&&($num[5]==4||$num[5]==8||$num[5]==9)&&($num[8]==4||$num[8]==8||$num[8]==9)) $total_points+=lineCheck(11,7);
if(($num[3]==4||$num[3]==8||$num[3]==9)&&($num[6]==4||$num[6]==8||$num[6]==9)&&($num[9]==4||$num[9]==8||$num[9]==9)) $total_points+=lineCheck(11,8);
}

if($crossmode==0)
{
	if($seven==2) $total_points=$total_points+($betmoney*2);   //����2
	else if($seven==3) $total_points=$total_points+($betmoney*5);   //����3	
	else if($seven==4) $total_points=$total_points+($betmoney*20);  //����4
	else if($seven==5) $total_points=$total_points+($betmoney*60);  //����5
	else if($seven==6) $total_points=$total_points+($betmoney*100); //����6
	else if($seven==7) $total_points=$total_points+($betmoney*200); //����7
	else if($seven==8) $total_points=$total_points+($betmoney*400); //����8
}	

/* ���̾� */

if($num[2]==$num[4]&&$num[4]==$num[6]&&$num[6]==$num[8]&&$num[8]==1&&$num[8]!=$num[1]&&$num[8]!=$num[3]&&$num[8]!=$num[5]&&$num[8]!=$num[7]&&$num[8]!=$num[9]){
	$total_points=$total_points+5000;
	$title="ü�� ���̾�";
}

if($num[2]==$num[4]&&$num[4]==$num[6]&&$num[6]==$num[8]&&$num[8]==5&&$num[8]!=$num[1]&&$num[8]!=$num[3]&&$num[8]!=$num[5]&&$num[8]!=$num[7]&&$num[8]!=$num[9]){
	$total_points=$total_points+5000;
	$title="���� ���̾�";
}


/* �簢 */

if($num[1]==$num[3]&&$num[3]==$num[7]&&$num[7]==$num[9]&&$num[9]==1&&$num[9]!=$num[2]&&$num[9]!=$num[4]&&$num[9]!=$num[5]&&$num[9]!=$num[6]&&$num[9]!=$num[8]){
       	$total_points=$total_points+5000;
		$title="ü�� �簢";
}

if($num[1]==$num[3]&&$num[3]==$num[7]&&$num[7]==$num[9]&&$num[9]==5&&$num[9]!=$num[2]&&$num[9]!=$num[4]&&$num[9]!=$num[5]&&$num[9]!=$num[6]&&$num[9]!=$num[8]){
       	$total_points=$total_points+5000;
		$title="���� �簢";
}



/* ���� */
if($num[2]==$num[4]&&$num[4]==$num[5]&&$num[5]==$num[6]&&$num[6]==$num[8]&&$num[8]==1){
	$total_points=$total_points+10000;
	$gamemsg="Bonus Wins";
	$title="ü�� ����";
}
if($num[2]==$num[4]&&$num[4]==$num[5]&&$num[5]==$num[6]&&$num[6]==$num[8]&&$num[8]==5){
	$total_points=$total_points+($betmoney*40)+$jackpot;
	$gamemsg="Bonus Wins";
	$rankdb=4;
	$title="���� ����";
	echo "<script>sevens=5;</script>";
}

/* ���� */
if($num[1]==$num[3]&&$num[3]==$num[7]&&$num[7]==$num[9]&&$num[9]==$num[5]&&$num[5]==1){
	$total_points=$total_points+10000;
	$gamemsg="Bonus Wins";
	$title="ü�� ����";
}

if($num[1]==$num[3]&&$num[3]==$num[7]&&$num[7]==$num[9]&&$num[9]==$num[5]&&$num[5]==5){
	$total_points=$total_points+($betmoney*40);
	$gamemsg="Bonus Wins";
	$title="���� ����";
	echo "<script>sevens=5;</script>";
}


/*�ð�����*/
for ($i=1;$i<10;$i++)
{
	if($num[$i]<4 && $allmode==100)
	{
		$fruits=$fruits+1;
		echo "<script>allfruit=allfruit+1;</script>";
	}
}

/*�� ���� */
if($fruits==9)
{
	for ($i=1;$i<10;$i++)
	{
		echo "<script>slotOn(".$i.");</script>";
	}

	$total_points=$total_points+($betmoney*15);
	$gamemsg="Fluits";
	$title="�� ����";
}

/* �� �׸� */
if($allbar==9 && $allmode==100)
{
	$total_points=$total_points+($betmoney*60);
	$gamemsg="AnyBar";
	$rankdb=3;
	$title="�� ���";
}

if($allbell==9 && $allmode==100)
{
	$total_points=$total_points+($betmoney*200);
	$gamemsg="AnyBell";
	$rankdb=3;
	$title="�� ����";
}

if($allmode==1){
	$total_points=$total_points+($betmoney*320);   
	$gamemsg="Cherries";
	$rankdb=2;
	$title="�� ü��";
}	

if($allmode==2){
	$total_points=$total_points+($betmoney*40);
	$gamemsg="Oranges";
	$rankdb=3;
	$title="�� ������";
}

if($allmode==3){
 	$total_points=$total_points+($betmoney*80);
	$gamemsg="Mangoes";
	$rankdb=3;
	$title="�� ����";
}

if($allmode==0){
	$total_points=$total_points+($betmoney*300);   
	$gamemsg="W.melons";
	$rankdb=3;
	$title="�� ����";
}	

if($allmode==4){
	$total_points=$total_points+($betmoney*150);
	$gamemsg="1Bars";
	$bars=$bars-24;
	$rankdb=3;
	$title="�� ����";
}

if($allmode==5){
	$total_points=$total_points+($betmoney*1000);
	$gamemsg="Jackpot Sevens";
	$rankdb=1;
	$title="�� ����";
}

if($allmode==6){
	$total_points=$total_points+($betmoney*200);
	$gamemsg="S.bells";
	$rankdb=2;
	$title="�� ������";
}

if($allmode==7){
	$total_points=$total_points+($betmoney*200);
	$gamemsg="Bells";
	$rankdb=3;
	$title="�� ����";
}

if($allmode==8){
	$total_points=$total_points+($betmoney*300);   
	$gamemsg="2Bars";
	$bars=$bars-32;
	$rankdb=2;
	$title="�� ����";
}	
if($allmode==9){
	$total_points=$total_points+($betmoney*500);   
	$gamemsg="3Bars";
	$bars=$bars-40;
	$rankdb=2;
	$title="�� ������";
}	

if($seven>=5)
	echo "<script>sevens=5;</script>";

if($bells>0)
{
	if($sdata[bell]<=$bells)
	{
	 @mysql_query("update zetyx_member_table set bellbonus=bellbonus+5 where user_id='$member[user_id]'",$connect) or error(mysql_error());
	 @mysql_query("update zetyx_member_table set bell=bell-$bells+5 where user_id='$member[user_id]'",$connect) or error(mysql_error());
	 echo "<script>top.setBetFalse();</script>";
	}
	else
	{
	 @mysql_query("update zetyx_member_table set bell=bell-$bells where user_id='$member[user_id]'",$connect) or error(mysql_error());
	}
}
if($mode!=1 && $bars>0)
{
	@mysql_query("update zetyx_member_table set bar=bar+$bars where user_id='$member[user_id]'",$connect) or error(mysql_error());
	echo "<script>top.setBetFalse();</script>";
}
	
switch($rankdb)
{
	case 1:
		@mysql_query("update zetyx_member_table set allseven=allseven+1, rankpoint=rankpoint+5 where user_id='$member[user_id]'",$connect) or error(mysql_error());
		echo "<script>top.setRecord(".($sdata[allseven]+1).",".$sdata[allitemh].",".$sdata[alliteml].",".$sdata[crossseven].");</script>";
		$all7=1;
		break;
	case 2:
		@mysql_query("update zetyx_member_table set allitemh=allitemh+1, rankpoint=rankpoint+3  where user_id='$member[user_id]'",$connect) or error(mysql_error());
		echo "<script>top.setRecord(".$sdata[allseven].",".($sdata[allitemh]+1).",".$sdata[alliteml].",".$sdata[crossseven].");</script>";
		$allh=1;
		break;
	case 3:
		@mysql_query("update zetyx_member_table set alliteml=alliteml+1, rankpoint=rankpoint+1  where user_id='$member[user_id]'",$connect) or error(mysql_error());
		echo "<script>top.setRecord(".$sdata[allseven].",".$sdata[allitemh].",".($sdata[alliteml]+1).",".$sdata[crossseven].");</script>";
		$alll=1;
		break;
	case 4:
		@mysql_query("update zetyx_member_table set crossseven=crossseven+1, rankpoint=rankpoint+1  where user_id='$member[user_id]'",$connect) or error(mysql_error());
		echo "<script>top.setRecord(".$sdata[allseven].",".$sdata[allitemh].",".$sdata[alliteml].",".($sdata[crossseven]+1).");</script>";
		$cro7=1;
		break;
	default :
		break;
		
}

if($total_points==0)
{
	$gamemsg="Game Over";
	echo "<script>gamemsg='".$gamemsg."';</script>";		
}
else
{
	$total_points=$total_points*$doublepoint;
	echo "<script>gamemsg='".$gamemsg."'+' ".$total_points." P';</script>";
	$gamemsg=$gamemsg+" "+$total_points;
}	

@mysql_query("update zetyx_member_table set gamepoint=gamepoint+$total_points,box1=$num[1],box2=$num[2],box3=$num[3],box4=$num[4],box5=$num[5],box6=$num[6],box7=$num[7],box8=$num[8],box9=$num[9] where user_id='$member[user_id]'",$connect) or error(mysql_error());

// ȭ�� ��ũ��Ʈ ����
echo "<script>setting(".$total_points.");</script>";

// �û�
}
else if($betmoney==0)
{
	echo "<script>alert('���øӴϸ� ������ �ּ���.');</script>";
	echo "<script>top.setPlay();</script>";
	echo "<script>top.focus();</script>";
}else {
	echo "<script>alert('���ӸӴϰ� �����մϴ�.');</script>";
	echo "<script>top.setPlay();</script>";
	echo "<script>top.focus();</script>";
}
?>
</head>
</html>